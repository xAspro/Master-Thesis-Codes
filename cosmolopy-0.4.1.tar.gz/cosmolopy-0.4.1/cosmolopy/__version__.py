# -*- coding: utf-8 -*-

# %% VERSIONS
# Default/Latest/Current version
__version__ = '0.4.1'
